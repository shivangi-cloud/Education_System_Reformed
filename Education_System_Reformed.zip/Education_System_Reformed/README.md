# Education System Reformed

A design study for a decentralised learning network in Lucknow, built to be read in a hundred years.

**No currency. No token. No cryptocurrency anywhere in the system.**

→ **[Read the atlas](https://shivangi-cloud.github.io/Education_System_Reformed/)** *(live once GitHub Pages is enabled)*

---

## What this is

Two documents, both self-contained HTML with no build step and no dependencies.

**`index.html` — Atlas 01.** Twelve diagram-led plates. The argument, mostly in geometry.

**`system-note.html` — the operational note.** The earlier, prose version: legal structure, governance rules, wireframes, order of operations. Narrower in scope — it assumed government schools only — but the operational detail still holds.

## The argument in one paragraph

Learning happens through a relationship with someone slightly more capable, doing something real together. Every attempt to scale that past what one person can supervise substitutes a proxy — a syllabus, a hall, an exam, a screen, a certificate. Roughly once a generation someone notices the proxy has eaten the thing and rebuilds. Ivan Illich specified the alternative in 1971: four open registries — objects, skills, peers, mentors — whose job is *connection*, not certification. He wrote a peer-matching algorithm by hand, before the internet could run it. This is an attempt to build that, in one city, with Gandhi's Nai Talim supplying the unit of account that isn't money and Ostrom's design principles supplying a constitution meant to outlive its founder.

## The twelve plates

| | |
|---|---|
| 01 | Illich's four learning webs as four registries |
| 02 | Illich = architecture, Gandhi = engine, Ostrom = constitution, Ambedkar = the plumb line |
| 03 | Lucknow as twelve education nodes — policy currently sees three |
| 04 | Effect-size calibration: everything you've heard is ~5× too large |
| 05 | The ledger, split between anchored and erasable |
| 06 | The open-standards credential stack |
| 07 | Why India, why now — the certificate fraud case |
| 08 | The failure to design against: registration is not use |
| 09 | Eight campaigns |
| 10 | The demographic clock |
| 11 | Order of operations — the software is step five |
| 12 | What every thinker in the canon got wrong |

## Technical position

The distributed-ledger surface of this system is **one periodic hash, published**. That is all. It holds no personal data.

Everything else runs on published, free, internationally maintained specifications:

- **`did:web`** — an issuer proves it signed something by resolving its own domain
- **W3C Verifiable Credentials 2.0** — Recommendation since May 2025
- **Open Badges 3.0** — a badge *is* a Verifiable Credential, since May 2024
- **Comprehensive Learner Record** — courses, competencies, workplace learning, learner-held
- **Bitstring Status List 1.0** — how you revoke without rewriting history

Personal data never touches the immutable layer. This is not fastidiousness — the DPDP Act grants a right to erasure, and an immutable record containing a child's name cannot honour it. APAAR, the national student ID, is being litigated on exactly this question.

### Precedent, so nobody has to take this on faith

- **CBSE** put ~12 crore documents (Class X and XII, 2004–2021) on a blockchain built by NIC, live and publicly verifiable
- **Maharashtra's** skill development board issued ~1 lakh diplomas on-chain — verification went from ~30 days to seconds
- **MeitY's National Strategy on Blockchain (2021)** names academic certificates as a target use case, in writing
- **MIT's** Digital Credentials Consortium started with blockchain diplomas in 2017 and has since moved to signed credentials with no ledger at all — worth knowing before overcommitting to a chain

## Intellectual sources

Illich · Freire · Dewey · Papert · Vygotsky · Montessori · Bloom · Ostrom · Benkler · Tagore · Gandhi · Ambedkar · Krishnamurti · Sri Aurobindo · Nalanda and Takshashila via Xuanzang and Yijing · Mitra, with Arora as the refutation · NEP 2020.

Evidence is drawn from Nickow/Oreopoulos/Quan on tutoring, Kraft on the 2-sigma inflation and on coaching, Muralidharan et al. on Mindspark, the World Bank Nigeria AI-tutoring RCT, Kestin et al. in *Scientific Reports*, Bastani et al. at Wharton on AI harming learning, Dunlosky et al. on what actually works, Kirschner/Sweller/Clark on guidance, Pritchett on isomorphic mimicry, the World Bank on Ceará and Sobral, and Banerjee/Banerji/Duflo/Glennerster/Khemani's Jaunpur trial — which tested a community-information model in Uttar Pradesh and found it moved nothing.

## Status

Draft for discussion. Nothing here has been built yet.

Figures with dates attached should be re-checked before use — particularly UDISE+ enrolment and infrastructure numbers, AKTU's affiliated-college count, the live status of the APAAR litigation and of UP's school-pairing case, and exact Academic Bank of Credits transfer figures. Plate 12 and the closing note of `system-note.html` list what could not be verified.

## Licence

[CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/). Use it, change it, share it forward under the same terms. A commons argument should be published on commons terms.
