#!/usr/bin/env bash
# Pushes the atlas to shivangi-cloud/Education_System_Reformed and prints the Pages URL.
# Run this from inside the unzipped folder:   bash push.sh
set -euo pipefail

REPO="https://github.com/shivangi-cloud/Education_System_Reformed.git"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

echo "→ cloning $REPO"
git clone --quiet "$REPO" "$TMP/repo"

echo "→ copying files"
cp "$HERE/index.html" "$HERE/system-note.html" "$HERE/README.md" "$HERE/LICENSE" "$TMP/repo/"
touch "$TMP/repo/.nojekyll"

cd "$TMP/repo"
git add -A

if git diff --cached --quiet; then
  echo "→ nothing to push, already up to date"
  exit 0
fi

git commit --quiet -m "Add Lucknow Learning Atlas — design study for a decentralised learning network

index.html        Atlas 01, twelve diagram-led plates
system-note.html  operational note: legal structure, governance, wireframes
README.md         the argument, the standards, the precedent
LICENSE           CC BY-SA 4.0

No currency, no token; the distributed-ledger surface is one published hash.
Built on W3C Verifiable Credentials 2.0, Open Badges 3.0 and did:web."

echo "→ pushing"
git push --quiet origin HEAD:main

cat <<'EOF'

Done.

  Repo   https://github.com/shivangi-cloud/Education_System_Reformed

One more click to make it a live site:
  Settings → Pages → Source: "Deploy from a branch" → main / (root) → Save

Then, after a minute or two:
  https://shivangi-cloud.github.io/Education_System_Reformed/

EOF
